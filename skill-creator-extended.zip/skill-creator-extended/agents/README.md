# Role prompts

The Markdown files in this directory describe reusable reviewer roles. They are prompt templates, not agent-registration manifests. Use them with a delegation feature only when the current host explicitly supports one; otherwise apply the relevant role inline.
