# Claude Code-only legacy utilities

These scripts are preserved from the source package for users who still run Claude Code.

They are not cross-harness utilities:

- `run_eval.py` calls `claude -p`, creates temporary files under `.claude/commands`, and inspects Claude Code stream events.
- `improve_description.py` calls `claude -p` to generate a revised description.
- `run_loop.py` combines those two scripts into an iterative trigger-optimization loop.

Do not run these scripts from Codex or OpenCode. They are not invoked by the main `SKILL.md` workflow. No Codex/OpenCode equivalent is included because reliable trigger measurement requires an explicit, harness-specific runner and must not be simulated.

To run them in a compatible Claude Code setup, invoke the loop from the skill root as a Python module:

```bash
python -m legacy.claude_code_only.scripts.run_loop --help
```

The command is retained for reference; availability depends on the installed Claude Code CLI and its current interface.
