---
name: skill-creator-extended
description: Create, inspect, repair, document, package, and improve reusable Agent Skills. Use when a user wants to design a new SKILL.md, adapt a Claude or other platform skill for Codex or OpenCode, review an existing skill, add scripts or references, validate a skill package, or evaluate whether a skill improves task results. Prefer the lightweight workflow unless the user explicitly requests testing or benchmarking.
compatibility: Designed for the Agent Skills format and shared use in Codex and OpenCode. Optional Python utilities require Python 3.10 or later; see README.md for dependencies.
---

# Skill Creator Extended

Create and improve portable, maintainable Agent Skills. This skill is designed for Codex and OpenCode and avoids depending on any one assistant's private tool names, CLI, agent API, or plugin format.

## Operating principles

1. **Reuse context.** First inspect the current conversation and supplied files. Do not ask the user to repeat information already provided.
2. **Stay faithful to the task.** Do not add workflows, requirements, files, or test stages that the user did not request and that are not necessary to deliver a usable skill.
3. **Use the lightest effective process.** Drafting and improving a skill does not automatically require a benchmark. The default is a focused design/edit pass and, when useful, one inexpensive structural validation.
4. **Do not invent capabilities.** Use only tools, subagents, browser access, and scripts that are actually available in the current host. Never assume a particular tool name or a particular subagent API.
5. **Keep the user in control.** Do not run repeated, parallel, networked, destructive, or high-token tests unless the user explicitly requests them. Explain material cost before a large evaluation.
6. **Preserve provenance.** Distinguish source-derived rules from recommendations. Do not silently change the meaning of an imported skill when adapting its platform-specific instructions.
7. **Make cross-harness behavior explicit.** Prefer portable Agent Skills conventions. Put platform-specific behavior in clearly labelled sections or adapters.

## Choose the right work mode

Use the least expensive mode that meets the request:

| Mode | Use when | Default actions |
|---|---|---|
| **Design / edit** | Creating or revising a skill | Inspect context, write or edit `SKILL.md`, add only necessary resources. No benchmark. |
| **Review / adapt** | Checking an imported or existing skill | Inspect all files, identify platform-specific assumptions, preserve useful content, document incompatibilities. |
| **Quick validation** | Preparing a skill for installation or packaging | Run `scripts/quick_validate.py` if Python is available; check links and referenced paths. No model runs. |
| **Quick behavior check** | The user asks to test the skill or correctness cannot reasonably be assessed statically | Use one representative prompt, or at most two distinct prompts when they cover separate critical paths. Do not run a baseline unless requested. |
| **Comparative benchmark** | The user explicitly asks whether a skill improves performance | Agree the scope and comparison design first. Use the smallest useful eval set and report model, tools, runs, cost, and limitations. |

Never promote a quick check into a full benchmark without a request. Avoid default test suites of 20 queries, repeated multi-run trigger evaluations, automatic improvement loops, and background polling. These are optional high-cost techniques, not routine setup steps.

## 1. Understand the request

Identify whether the user wants to:

- create a skill from scratch;
- revise or repair an existing skill;
- adapt a skill from Claude, Cursor, or another host to Codex / OpenCode;
- review a skill package before installation;
- validate or package a completed skill;
- evaluate skill quality or triggering behavior.

Extract information already present in the conversation or source files. Confirm only essential unknowns. A useful skill specification usually includes:

- the task the skill enables;
- when it should and should not be used;
- expected inputs and outputs;
- workflow and decision rules;
- dependencies, scripts, and external services;
- constraints, safety boundaries, and failure handling;
- the target harness or harnesses.

If the target is not specified, prefer portable Agent Skills conventions and avoid platform-specific features.

## 2. Inspect imported skills before editing

When adapting an existing skill:

1. List the archive contents and identify the actual skill directory containing `SKILL.md`.
2. Read `SKILL.md` and every referenced instruction, script, schema, template, and configuration file that affects its behavior.
3. Search for platform-specific references, including private tool names, `claude -p`, Claude Code commands, `.claude/commands`, plugin manifests, proprietary agent APIs, environment variables, and assumptions about browser or background execution.
4. Classify each component as:
   - **portable** — keep as-is or make only minor wording changes;
   - **adaptable** — rewrite the instructions for the target host;
   - **host-specific** — isolate under a clearly named `legacy/` or adapter folder, or remove if not needed;
   - **unavailable / unverified** — document the limitation instead of claiming support.
5. Preserve the original method and terminology unless a change is required for compatibility or explicitly requested.
6. Check license files and preserve applicable notices.

Do not treat an archive's plugin manifest as proof that the content is a plugin for another host. A folder containing `SKILL.md` is a skill; plugin packaging and installation are separate mechanisms.

## 3. Create or revise `SKILL.md`

### Frontmatter

Use a YAML frontmatter block at the beginning of the file. For broad compatibility, keep to the common fields:

```yaml
---
name: concise-kebab-case-name
description: Explain what the skill does and the user intents that should trigger it.
compatibility: Optional runtime or dependency requirements.
---
```

Rules:

- `name` must be lowercase kebab-case, 1–64 characters, and match the skill folder name.
- `description` should clearly describe both the task and the contexts in which the skill is useful. Keep it specific, natural, and below 1024 characters.
- Do not make the description a long keyword dump or an aggressive instruction to trigger on unrelated requests.
- Use optional metadata only when it adds useful, portable information.
- Avoid host-specific frontmatter fields unless the target platform explicitly requires them.

### Body and organization

A useful `SKILL.md` normally contains:

1. **Purpose and scope** — what the skill does and does not do.
2. **Trigger guidance** — when to use it, with relevant exclusions.
3. **Workflow** — ordered, actionable steps.
4. **Decision rules** — how to choose between approaches.
5. **Inputs and outputs** — expected formats and locations.
6. **Validation** — how to check results and what validation cannot prove.
7. **Failure handling** — how to report missing information, unsupported formats, and tool errors.
8. **Resource map** — when to read files under `references/`, `scripts/`, `agents/`, or `assets/`.

Keep the main file focused and preferably under 500 lines. Use progressive disclosure: load detailed references only when the relevant task requires them. Use imperative instructions, explain the reason behind important constraints, and avoid repeating the same rule in multiple places.

### Recommended directory layout

```text
skill-name/
├── SKILL.md
├── README.md                 # optional install/use notes
├── references/               # detailed reference material
├── scripts/                  # deterministic helpers
├── assets/                   # templates and static resources
├── agents/                   # role prompts, not automatically registered agents
└── evals/                    # optional test cases; do not add by default
```

Add only directories that are actually needed. Do not create placeholder files or a test suite merely to make the package look complete.

## 4. Write portable instructions for Codex and OpenCode

- Refer to the current assistant as **the agent** or **the model**, not Claude, unless the task is specifically about Claude.
- Do not hard-code tool names such as `Task`, `Skill`, `Read`, or `Bash` as if every host exposes them. Describe the required capability (read a file, execute a script, delegate a bounded task) and let the host map it to its actual tools.
- Do not assume subagents exist. If the host supports delegation, delegate only when it materially helps. Otherwise perform the work inline.
- Treat files in `agents/` as reusable role prompts. Their presence does not automatically register them as separately callable agents in Codex or OpenCode.
- Use paths relative to the skill directory when referencing bundled resources. Quote paths containing spaces.
- Prefer Python standard-library utilities where practical. State external dependencies, supported Python version, and exact commands.
- Use portable shell commands or provide Windows PowerShell alternatives when shell behavior differs materially.
- Do not assume a browser can be opened, a local server can be started, or a process can run in the background. Provide a static-file fallback where possible.
- Do not assume the current model can inspect its own trigger/selection decision. Trigger evaluation must be performed using the actual target harness and a reproducible method.

### Harness-specific notes

The shared skill format is intentionally the same, but discovery and some runtime behavior are controlled by each host. When installation instructions are requested, verify current official documentation if web access is available.

- **Codex:** user-level skills can be placed under `$HOME/.agents/skills/<skill-name>/`. Repository-level skills can live under `.agents/skills/<skill-name>/` within the repository.
- **OpenCode:** supports Agent Skills in `.agents/skills` locations as well as its own configured skill directories. The user-level shared location is `~/.agents/skills/<skill-name>/`.
- A shared user-level `.agents/skills` directory is the preferred location when the user wants the same skill in both tools. A repository-level directory is preferable when the skill should travel with one project.
- Do not install a skill in `plugins/` unless the user is explicitly building or installing a plugin package for a host that supports it.

## 5. Add scripts and references only when justified

Before adding a script, ask whether the work is deterministic, repeated, and valuable enough to justify code. If not, keep the process in the instructions.

For every script:

- document what it does and the exact invocation;
- validate arguments and report actionable errors;
- avoid destructive changes by default;
- do not silently overwrite user files;
- avoid hidden network calls or credential access;
- write outputs to a clearly named folder;
- make paths relative to the skill or explicitly explain the working-directory requirement;
- include a dependency note and a lightweight way to verify the script.

For references, include clear links from `SKILL.md` describing exactly when each reference should be read. Avoid loading all reference files on every use.

## 6. Evaluate only when useful

### Create a small eval set

When testing is requested or materially useful, create `evals/evals.json`. Start with 1–3 realistic prompts that cover distinct critical behaviors. Include input files only when they are necessary and available. Each eval should state what a successful result looks like.

Example:

```json
{
  "skill_name": "example-skill",
  "evals": [
    {
      "id": 1,
      "prompt": "A realistic task prompt",
      "expected_output": "A concise description of the expected result",
      "files": [],
      "expectations": [
        "The output contains the required sections",
        "No unsupported facts are introduced"
      ]
    }
  ]
}
```

See `references/schemas.md` for optional result structures.

### Quick behavior check

When the user requests a quick check:

1. Use one representative prompt; add a second only if it tests a materially different behavior.
2. Run it with the target skill in the target harness where possible.
3. Inspect the actual outputs, not just a completion message.
4. Compare the result against the expected outcome and note any unverified claims.
5. Report the check's limitations. A single successful run is a sanity check, not proof of general reliability.

Do not run a baseline, multiple repetitions, or separate graders by default.

### Comparative benchmark

Only use a comparative benchmark when the user explicitly asks for evidence that a skill improves outcomes or requests an A/B evaluation.

Before starting, define:

- what is being compared (no skill vs skill, or old vs new version);
- one or more outcome-based evals;
- the same model, input files, tools, and relevant settings for each configuration;
- the minimum number of repetitions needed for the decision;
- how much output, token use, and time the user is willing to spend.

Keep the comparison fair. Capture timing and token counts only when the host actually exposes them; never invent or estimate them as observed metrics. If parallel independent agents are unavailable, do not pretend that runs were independent. Label qualitative judgments separately from measured metrics.

### Grading and blind comparison

Use `agents/grader.md`, `agents/comparator.md`, or `agents/analyzer.md` as role prompts only when those analyses are needed. If delegation is unavailable, apply the role instructions inline. A grader must cite observable evidence from transcripts or files. A blind comparator must not be given information that reveals which version produced output A or B.

## 7. Review results and iterate

After reviewing test outputs:

1. Identify repeated, consequential failure patterns.
2. Change only the instructions or resources that plausibly caused those failures.
3. Avoid overfitting a skill to one prompt or one example.
4. Preserve a copy of the previous version before substantial changes.
5. Re-run only the smallest check that can show whether the change helped.
6. Stop when the user is satisfied, the remaining issues are immaterial, or further iterations are not producing meaningful improvement.

Do not keep iterating simply because more iterations are possible.

## 8. Review triggering descriptions carefully

The `description` field is important for skill discovery, but its triggering behavior is host- and model-dependent. Do not claim that a description has been optimized for Codex or OpenCode based only on a manually generated query list.

A useful low-cost review is to check whether the description:

- states the actual user goal;
- includes the main intents and situations where the skill is useful;
- distinguishes the skill from adjacent skills;
- avoids triggering on broad, unrelated requests;
- remains concise and below the platform limit.

Automated trigger-rate optimization is optional and requires a harness-specific runner. The scripts in `legacy/claude_code_only/` are specifically tied to Claude Code and must not be used as Codex or OpenCode runners.

## 9. Validate and package

When the user wants an installable package:

1. Run `python scripts/quick_validate.py <path-to-skill-folder>` if Python and its optional validation dependency are available.
2. Check that referenced files exist and that the skill folder name matches the `name` in frontmatter.
3. Review included scripts for dependencies and platform-specific assumptions.
4. Package the skill only after validation. `python scripts/package_skill.py <path-to-skill-folder> <output-directory>` creates a `.skill` archive for compatible distribution workflows; for direct Codex/OpenCode installation, the ordinary folder containing `SKILL.md` is sufficient.
5. For a plain ZIP, preserve one top-level folder named exactly like the skill. Do not wrap the skill in an extra unrelated directory.

Do not describe a `.skill` archive as a plugin. Plugin packaging is a separate host-specific distribution path.

## Resource map

- `agents/grader.md` — evidence-based evaluation of outputs and test expectations.
- `agents/comparator.md` — blind comparison of two outputs.
- `agents/analyzer.md` — analysis of benchmark patterns and comparison outcomes.
- `references/schemas.md` — optional JSON structures for evals, grades, timing, and benchmarks.
- `scripts/quick_validate.py` — structural validation of a skill folder.
- `scripts/package_skill.py` — creates a `.skill` archive after validation.
- `scripts/aggregate_benchmark.py` — aggregates already-collected benchmark results; it does not run model evaluations.
- `eval-viewer/generate_review.py` — creates a human review page from prepared evaluation outputs; use `--static <output.html>` when a self-contained HTML file is preferable to starting a local server.
- `legacy/claude_code_only/` — retained Claude Code-specific scripts. Do not invoke them from Codex or OpenCode.

## Final response checklist

When delivering a skill, briefly state:

- what was created or changed;
- which hosts and installation path are supported;
- what remains host-specific or untested;
- validation performed and its actual result;
- the exact folder or archive to install.

Never claim that a skill is fully tested in both Codex and OpenCode unless it was actually executed in both.
